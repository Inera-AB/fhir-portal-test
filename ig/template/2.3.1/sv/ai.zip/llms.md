# inera.core.template#2.3.1: Inera FHIR Implementation Guide Template(sv)

## Pages

* [Hem](index.md)
* [Nedladdningar](downloads.md)
* [Säkerhet och behörighet](security.md)
* [CapabilityStatement](capabilitystatement.md)
* [Inledning](introduction.md)
* [Förväntade svar](expected-responses.md)
* [Informationsunderlag](information-basis.md)
* [Testning och validering](testing.md)
* [Mappning till profiler](mappings.md)
* [Användningsfall](use-cases.md)
* [Felhantering](error-handling.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Versionshistorik](version-history.md)
* [Om](about.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)

### ImplementationGuides

* [Inera FHIR Implementation Guide Template](ImplementationGuide-inera.core.template.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
